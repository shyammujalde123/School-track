import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firestore_service.dart';

class LocationService {
  final FirestoreService firestore;
  StreamSubscription<Position>? _subscription;
  LocationService(this.firestore);

  Future<bool> ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) return false;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    return p == LocationPermission.always || p == LocationPermission.whileInUse;
  }

  Future<Position?> current() async => await ensurePermission() ? Geolocator.getCurrentPosition() : null;

  Future<void> startTripTracking(String tripId) async {
    if (!await ensurePermission()) return;
    await _subscription?.cancel();
    _subscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 20),
    ).listen((p) => firestore.updateTripLocation(tripId, GeoPoint(p.latitude, p.longitude)));
  }

  Future<void> stop() async { await _subscription?.cancel(); _subscription = null; }
}
