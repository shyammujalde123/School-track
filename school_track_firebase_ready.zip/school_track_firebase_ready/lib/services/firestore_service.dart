import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore db = FirebaseFirestore.instance;

  Stream<DocumentSnapshot<Map<String, dynamic>>> userDoc(String uid) =>
      db.collection('users').doc(uid).snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> students() =>
      db.collection('students').orderBy('name').snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> activeTrips() =>
      db.collection('trips').where('status', isEqualTo: 'active').snapshots();

  Future<void> updateUser(String uid, Map<String, dynamic> data) =>
      db.collection('users').doc(uid).set(data, SetOptions(merge: true));

  Future<void> updateStudentLocation(String studentId, String type, GeoPoint point) =>
      db.collection('students').doc(studentId).set({type: point, 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));

  Future<void> updateTripLocation(String tripId, GeoPoint point) =>
      db.collection('trips').doc(tripId).set({'location': point, 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));

  Future<DocumentReference<Map<String, dynamic>>> createPickupRequest(Map<String, dynamic> data) =>
      db.collection('pickupRequests').add({...data, 'createdAt': FieldValue.serverTimestamp(), 'status': 'pending'});
}
