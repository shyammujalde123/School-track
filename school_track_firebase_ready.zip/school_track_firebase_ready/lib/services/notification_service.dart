import 'package:firebase_messaging/firebase_messaging.dart';

class NotificationService {
  final FirebaseMessaging messaging = FirebaseMessaging.instance;

  Future<void> init() async {
    await messaging.requestPermission(alert: true, badge: true, sound: true);
    await messaging.getToken(); // Save this token under users/{uid}.fcmTokens in production.
  }

  Stream<RemoteMessage> get messages => FirebaseMessaging.onMessage;
}
