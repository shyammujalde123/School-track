import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'firebase_options.dart';
import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'services/location_service.dart';
import 'services/notification_service.dart';
import 'driver_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try { await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform); } catch (_) {}
  try { await NotificationService().init(); } catch (_) {}
  runApp(const SchoolTrackApp());
}

class SchoolTrackApp extends StatelessWidget {
  const SchoolTrackApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'School Track',
    theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
    home: const RootPage(),
  );
}

class RootPage extends StatelessWidget {
  const RootPage({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: AuthService().userChanges,
    builder: (_, s) => s.data == null ? const LoginPage() : const HomePage(),
  );
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final email=TextEditingController(), pass=TextEditingController(); bool loading=false; String? error;
  Future<void> go() async {
    setState(()=>loading=true); error=null;
    try { await AuthService().signIn(email.text, pass.text); }
    on FirebaseAuthException catch(e){ setState(()=>error=e.message ?? e.code); }
    catch(e){ setState(()=>error=e.toString()); }
    if(mounted) setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth:420), child: Column(children:[
    const Icon(Icons.directions_bus, size:72), const SizedBox(height:12), const Text('School Track', style: TextStyle(fontSize:30,fontWeight:FontWeight.bold)),
    const SizedBox(height:28), TextField(controller:email, keyboardType:TextInputType.emailAddress, decoration:const InputDecoration(labelText:'Email',prefixIcon:Icon(Icons.email),border:OutlineInputBorder())),
    const SizedBox(height:12), TextField(controller:pass, obscureText:true, decoration:const InputDecoration(labelText:'Password',prefixIcon:Icon(Icons.lock),border:OutlineInputBorder())),
    if(error!=null) Padding(padding:const EdgeInsets.only(top:12),child:Text(error!,style:const TextStyle(color:Colors.red))),
    const SizedBox(height:16), SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:go, child:Text(loading?'Signing in…':'Sign in'))),
    const SizedBox(height:8), const Text('Create users in Firebase Authentication, then assign role in users/{uid}.role.'),
  ]))));
}

class HomePage extends StatelessWidget { const HomePage({super.key});
  @override Widget build(BuildContext context)=>StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(stream:FirestoreService().userDoc(FirebaseAuth.instance.currentUser!.uid),builder:(c,s){
    final role=(s.data?.data()?['role']??'parent').toString();
    if(role=='driver') return const DriverPage();
    if(role=='admin') return const AdminPage();
    return const ParentShell();
  });
}
class ParentShell extends StatefulWidget { const ParentShell({super.key}); @override State<ParentShell> createState()=>_ParentShellState(); }
class _ParentShellState extends State<ParentShell>{int tab=0; @override Widget build(BuildContext context){final pages=[const DashboardPage(),const MapPage(),const StudentsPage(),const RequestsPage(),const ProfilePage()];return Scaffold(appBar:AppBar(title:const Text('School Track')),body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[NavigationDestination(icon:Icon(Icons.dashboard),label:'Home'),NavigationDestination(icon:Icon(Icons.map),label:'Live'),NavigationDestination(icon:Icon(Icons.school),label:'Students'),NavigationDestination(icon:Icon(Icons.place),label:'Requests'),NavigationDestination(icon:Icon(Icons.person),label:'Profile')]));}}
class AdminPage extends StatelessWidget { const AdminPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('School Track Admin'),actions:[IconButton(onPressed:()=>AuthService().signOut(),icon:const Icon(Icons.logout))]),body:ListView(padding:const EdgeInsets.all(16),children:[const Text('Admin overview',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:12),StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirestoreService().students(),builder:(c,s)=>Card(child:ListTile(title:const Text('Students'),trailing:Text('${s.data?.docs.length??0}')))),StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirestoreService().activeTrips(),builder:(c,s)=>Card(child:ListTile(title:const Text('Active trips'),trailing:Text('${s.data?.docs.length??0}')))),const Card(child:ListTile(title:Text('Data collections'),subtitle:Text('users • students • buses • trips • pickupRequests • notifications')))]));}}


class DashboardPage extends StatelessWidget { const DashboardPage({super.key});
  @override Widget build(BuildContext context)=>StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirestoreService().students(),builder:(c,s){final count=s.data?.docs.length??0;return ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:ListTile(leading:const Icon(Icons.people),title:const Text('Students'),trailing:Text('$count',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)))),
    const Card(child:ListTile(leading:Icon(Icons.directions_bus),title:Text('Live trips'),subtitle:Text('Updates appear from driver GPS.'))),
    const Card(child:ListTile(leading:Icon(Icons.notifications),title:Text('Notifications'),subtitle:Text('Firebase Cloud Messaging ready.'))),
    Card(child:ListTile(leading:const Icon(Icons.edit_location_alt),title:const Text('Pickup / Drop'),subtitle:const Text('Parents can submit route-change requests.'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PickupPage())))),
  ];}); }
}

class StudentsPage extends StatelessWidget { const StudentsPage({super.key});
  @override Widget build(BuildContext context)=>StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirestoreService().students(),builder:(c,s){if(s.hasError)return Center(child:Text('Firestore error: ${s.error}')); if(!s.hasData)return const Center(child:CircularProgressIndicator()); if(s.data!.docs.isEmpty)return const Center(child:Text('No students found.'));return ListView(children:s.data!.docs.map((d){final x=d.data();return ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text('${x['name']??'Student'}'),subtitle:Text('Pickup: ${x['pickupPoint']??'-'}  •  Drop: ${x['dropPoint']??'-'}'),trailing:Text('${x['status']??'pending'}'));}).toList());});}
}

class RequestsPage extends StatelessWidget { const RequestsPage({super.key});
 @override Widget build(BuildContext context)=>StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirestoreService().db.collection('pickupRequests').orderBy('createdAt',descending:true).snapshots(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());return ListView(children:s.data!.docs.map((d){final x=d.data();return ListTile(title:Text(x['studentName']??'Student'),subtitle:Text('${x['pickupPoint']??'-'} → ${x['dropPoint']??'-'}'),trailing:Text(x['status']??'pending'));}).toList());}
}

class PickupPage extends StatefulWidget { const PickupPage({super.key}); @override State<PickupPage> createState()=>_PickupPageState(); }
class _PickupPageState extends State<PickupPage>{final name=TextEditingController(),pickup=TextEditingController(),drop=TextEditingController();bool busy=false;
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Pickup / Drop Request')),body:ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Student name')),TextField(controller:pickup,decoration:const InputDecoration(labelText:'Pickup point')),TextField(controller:drop,decoration:const InputDecoration(labelText:'Drop point')),const SizedBox(height:16),FilledButton(onPressed:busy?null:()async{setState(()=>busy=true);await FirestoreService().createPickupRequest({'studentName':name.text,'pickupPoint':pickup.text,'dropPoint':drop.text,'parentUid':FirebaseAuth.instance.currentUser?.uid});if(mounted){setState(()=>busy=false);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Request submitted')));Navigator.pop(context);}},child:Text(busy?'Submitting…':'Submit request'))]));}

class MapPage extends StatelessWidget { const MapPage({super.key});
 @override Widget build(BuildContext context)=>StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirestoreService().activeTrips(),builder:(c,s){final markers=<Marker>{};if(s.hasData){for(final d in s.data!.docs){final g=d.data()['location'];if(g is GeoPoint)markers.add(Marker(markerId:MarkerId(d.id),position:LatLng(g.latitude,g.longitude),infoWindow:InfoWindow(title:d.data()['busNumber']??'School Bus')));}}return GoogleMap(initialCameraPosition:const CameraPosition(target:LatLng(22.7196,75.8577),zoom:12),markers:markers,myLocationEnabled:true);}); }
}

class ProfilePage extends StatelessWidget { const ProfilePage({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[ListTile(leading:const Icon(Icons.email),title:Text(FirebaseAuth.instance.currentUser?.email??'-')),const Divider(),ListTile(leading:const Icon(Icons.logout),title:const Text('Sign out'),onTap:()=>AuthService().signOut())]); }
