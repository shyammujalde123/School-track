// Generated-style placeholder. Replace values by running `flutterfire configure`.
// Do NOT commit real production credentials to a public repository.
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return const FirebaseOptions(
        apiKey: 'REPLACE_ME', appId: 'REPLACE_ME', messagingSenderId: 'REPLACE_ME', projectId: 'REPLACE_ME');
    }
    return const FirebaseOptions(
      apiKey: 'REPLACE_ME',
      appId: 'REPLACE_ME',
      messagingSenderId: 'REPLACE_ME',
      projectId: 'REPLACE_ME',
      storageBucket: 'REPLACE_ME',
    );
  }
}
