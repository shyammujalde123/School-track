import 'package:flutter/material.dart';
import 'services/firestore_service.dart';
import 'services/location_service.dart';

class DriverPage extends StatefulWidget { const DriverPage({super.key}); @override State<DriverPage> createState()=>_DriverPageState(); }
class _DriverPageState extends State<DriverPage>{final id=TextEditingController();bool running=false;late final LocationService loc;
 @override void initState(){super.initState();loc=LocationService(FirestoreService());}
 @override void dispose(){loc.stop();id.dispose();super.dispose();}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Driver Console')),body:ListView(padding:const EdgeInsets.all(16),children:[
 TextField(controller:id,decoration:const InputDecoration(labelText:'Trip ID',border:OutlineInputBorder())),const SizedBox(height:12),
 Card(child:ListTile(leading:Icon(running?Icons.gps_fixed:Icons.gps_off),title:Text(running?'GPS tracking active':'GPS tracking stopped'),subtitle:const Text('Location is sent to Firestore every ~20 metres.'))),
 FilledButton.icon(onPressed:running?null:()async{if(id.text.trim().isEmpty)return;await loc.startTripTracking(id.text.trim());setState(()=>running=true);},icon:const Icon(Icons.play_arrow),label:const Text('Start trip & GPS')),
 const SizedBox(height:8),OutlinedButton.icon(onPressed:running?()async{await loc.stop();setState(()=>running=false);}:null,icon:const Icon(Icons.stop),label:const Text('Stop GPS')),
 ]));}
